define({
  "name": "node-admin-backend",
  "version": "1.0.0",
  "description": "node-admin-backend管理台的API文档, 所有接口都需要携带token和username在请求头",
  "title": "Vue后台API接口文档 ",
  "url": "http://localhost:3000",
  "sampleUrl": "http://localhost:3000",
  "forceLanguage": "zh-cn",
  "template": {
    "withCompare": true,
    "withGenerator": true
  },
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2021-08-25T08:27:02.220Z",
    "url": "https://apidocjs.com",
    "version": "0.29.0"
  }
});
