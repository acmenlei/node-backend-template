const redis = require('redis'),
      connect = redis.createClient();

module.exports = connect