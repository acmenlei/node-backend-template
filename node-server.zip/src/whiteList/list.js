const whileList =
    [
        '/admin/login', '/admin/register', '/admin/verify'
    ];

module.exports = whileList;